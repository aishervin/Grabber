
import React from 'react';

export const Footer: React.FC = () => {
    return (
        <footer className="w-full text-center py-6 relative z-10">
            <a 
                href="https://t.me/shervini" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[10px] font-bold tracking-[0.4em] text-[#222] hover:text-orange-500 transition-colors duration-300 uppercase"
            >
                Exclusive SHΞN™ made
            </a>
        </footer>
    );
};
