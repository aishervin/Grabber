import React, { useState } from 'react';
import { generateSearchQuery } from '../services/geminiService';
import { LoaderIcon, CopyIcon, CheckIcon } from './Icons';

interface QueryHelperModalProps {
    isOpen: boolean;
    onClose: () => void;
    onQueryGenerated: (query: string) => void;
}

export const QueryHelperModal: React.FC<QueryHelperModalProps> = ({ isOpen, onClose, onQueryGenerated }) => {
    const [userInput, setUserInput] = useState('');
    const [generatedQuery, setGeneratedQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [copied, setCopied] = useState(false);

    if (!isOpen) return null;

    const handleGenerate = async () => {
        if (!userInput.trim()) {
            setError('Please describe what you want to find.');
            return;
        }
        setIsLoading(true);
        setError('');
        setGeneratedQuery('');

        try {
            const query = await generateSearchQuery(userInput);
            setGeneratedQuery(query);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(`Failed to generate query: ${errorMessage}`);
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopyAndUse = () => {
        if (!generatedQuery) return;
        navigator.clipboard.writeText(generatedQuery);
        setCopied(true);
        setTimeout(() => {
            onQueryGenerated(generatedQuery);
            // Reset state for next time
            setUserInput('');
            setGeneratedQuery('');
            setCopied(false);
        }, 1000);
    };

    const handleModalClose = (e: React.MouseEvent<HTMLDivElement>) => {
        // Only close if the backdrop is clicked, not the content inside
        if (e.target === e.currentTarget) {
            onClose();
        }
    }

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50" onClick={handleModalClose}>
            <div className="bg-gray-800 border border-gray-700 rounded-2xl shadow-xl w-full max-w-2xl p-6 space-y-4 animate-fade-in" onClick={e => e.stopPropagation()}>
                <h2 className="text-xl font-bold text-indigo-400">AI Query Assistant</h2>
                <p className="text-gray-400">Describe what you're looking for on GitHub in plain language, and our AI will craft the perfect search query for you.</p>

                <div className="space-y-2">
                    <label htmlFor="user-prompt" className="text-sm font-medium text-gray-300">Your search goal:</label>
                    <textarea
                        id="user-prompt"
                        value={userInput}
                        onChange={e => setUserInput(e.target.value)}
                        placeholder="e.g., 'Python source code for a Telegram group management bot' or 'Active v2ray subscription links for USA servers'"
                        className="w-full h-24 px-4 py-2 bg-gray-900/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all duration-300 resize-none"
                        disabled={isLoading}
                    />
                </div>

                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !userInput.trim()}
                    className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white font-bold rounded-lg shadow-lg hover:bg-indigo-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300"
                >
                    {isLoading ? <><LoaderIcon /> Generating...</> : 'Generate GitHub Query'}
                </button>

                {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                
                {generatedQuery && (
                    <div className="space-y-3 pt-4 border-t border-gray-600">
                        <h3 className="text-lg font-semibold text-gray-300">AI-Generated Query:</h3>
                        <div className="bg-gray-900/70 p-4 rounded-lg border border-gray-700 font-mono text-green-300 break-words">
                            {generatedQuery}
                        </div>
                         <button
                            onClick={handleCopyAndUse}
                            className="w-full flex items-center justify-center gap-2 px-6 py-2 bg-green-600 text-white font-bold rounded-lg shadow-lg hover:bg-green-700 transition-all duration-300"
                        >
                            {copied ? <><CheckIcon/> Copied!</> : <><CopyIcon/> Copy & Use Query</>}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};
