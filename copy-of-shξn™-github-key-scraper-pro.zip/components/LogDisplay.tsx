
import React, { useEffect, useRef } from 'react';
import type { LogEntry } from '../types';

interface LogDisplayProps {
    logs: LogEntry[];
}

const LogItem: React.FC<{ entry: LogEntry }> = ({ entry }) => {
    const colorClasses = {
        info: 'text-gray-400',
        success: 'text-green-400',
        error: 'text-red-400',
    };

    return (
        <div className="flex items-start text-sm">
            <span className="font-mono text-gray-500 mr-3">{entry.timestamp}</span>
            <p className={`${colorClasses[entry.type]} flex-1`}>{entry.message}</p>
        </div>
    );
};


export const LogDisplay: React.FC<LogDisplayProps> = ({ logs }) => {
    const logContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [logs]);

    return (
        <div ref={logContainerRef} className="w-full h-48 bg-gray-900/70 rounded-lg p-4 overflow-y-auto border border-gray-700 font-mono space-y-2">
            {logs.length === 0 ? (
                <div className="flex items-center justify-center h-full text-gray-500">
                    Process logs will appear here...
                </div>
            ) : (
                logs.map((log, index) => <LogItem key={index} entry={log} />)
            )}
        </div>
    );
};
