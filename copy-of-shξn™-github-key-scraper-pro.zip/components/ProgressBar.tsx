
import React from 'react';
import type { ScrapeStatus } from '../types';

interface ProgressBarProps {
    progress: number;
    status: ScrapeStatus;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ progress, status }) => {
    const getBarColor = () => {
        switch (status) {
            case 'processing':
                return 'bg-orange-500 shadow-[0_0_15px_rgba(255,85,0,0.8)]';
            case 'success':
                return 'bg-green-500 shadow-[0_0_15px_rgba(16,185,129,0.8)]';
            case 'error':
                return 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.8)]';
            default:
                return 'bg-gray-800';
        }
    };
    
    const barColor = getBarColor();

    return (
        <div className="w-full bg-[#050505] h-1 border-b border-white/10 overflow-hidden">
            <div
                className={`h-full transition-all duration-300 ease-out ${barColor}`}
                style={{ width: `${progress}%` }}
            ></div>
        </div>
    );
};
