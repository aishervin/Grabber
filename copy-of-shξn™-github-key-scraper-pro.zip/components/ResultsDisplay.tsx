
import React, { useState } from 'react';
import type { ScrapeResults } from '../types';
import { DownloadIcon, CopyIcon, CheckIcon } from './Icons';

interface ResultsDisplayProps {
    results: ScrapeResults;
    addLog: (message: string, type?: 'info' | 'error' | 'success') => void;
}

const KeyItem: React.FC<{ apiKey: string }> = ({ apiKey }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(apiKey);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="bg-black p-3 rounded border border-white/10 group hover:border-orange-500/50 transition-colors duration-300">
            <div className="flex items-center justify-between">
                <code className="text-[10px] font-mono text-gray-500 break-all group-hover:text-orange-500 transition-colors">{apiKey}</code>
                <button
                    onClick={handleCopy}
                    className={`flex items-center justify-center p-2 rounded transition-all duration-200 ${copied ? 'bg-green-900/20 text-green-500' : 'bg-transparent hover:bg-orange-500/10 text-gray-700 hover:text-orange-500'}`}
                    aria-label={copied ? 'Copied' : 'Copy API key'}
                >
                    {copied ? <CheckIcon /> : <CopyIcon />}
                </button>
            </div>
        </div>
    );
};

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ 
    results, 
    addLog,
}) => {
    const potentialKeysCount = Object.values(results).reduce((sum: number, keys: string[] | undefined) => sum + (Array.isArray(keys) ? keys.length : 0), 0);

    const servicesWithPotentialKeys = Object.keys(results).filter(
        service => Array.isArray(results[service]) && results[service]!.length > 0
    );

    const handleDownload = (service: string) => {
        const keys = results[service as keyof typeof results];
        if (!keys || keys.length === 0) {
            addLog(`No ${service} keys to download.`, 'info');
            return;
        }

        const content = keys.join('\n');
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${service.toLowerCase().replace(' ', '_')}_keys.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        addLog(`📥 Downloading ${a.download}`, 'success');
    };

    return (
        <div className="w-full pt-8 border-t border-white/5 space-y-6 animate-fade-in">
            <header className="flex items-center gap-3">
                 <div className="h-1 w-1 bg-orange-500 rounded-full animate-pulse"></div>
                 <h2 className="text-xs font-bold text-gray-500 uppercase tracking-[0.2em]">Captured Data ({potentialKeysCount})</h2>
            </header>

            <div className="grid md:grid-cols-2 gap-6">
                {servicesWithPotentialKeys.length === 0 ? (
                    <p className="text-gray-700 text-center md:col-span-2 py-8 text-xs uppercase tracking-widest">
                        No artifacts secured.
                    </p>
                ) : (
                    servicesWithPotentialKeys.map(service => (
                        <section key={service} className="bg-[#0a0a0a] border border-white/5 rounded-lg p-4 shadow-lg">
                             <div className="flex items-center justify-between mb-4">
                                <h3 className="text-xs font-bold text-orange-500 uppercase tracking-wider">{service}</h3>
                                <button
                                    onClick={() => handleDownload(service)}
                                    className="flex items-center justify-center gap-2 px-3 py-1.5 bg-transparent hover:bg-orange-900/20 border border-gray-800 hover:border-orange-500/50 text-gray-500 hover:text-orange-500 text-[10px] font-bold rounded transition-all"
                                >
                                    <DownloadIcon />
                                    DOWNLOAD ({results[service]!.length})
                                </button>
                            </div>
                            <div className="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                                {results[service]!.map((key, index) => <KeyItem key={`${service}-pot-${index}`} apiKey={key} />)}
                            </div>
                        </section>
                    ))
                )}
            </div>
        </div>
    );
};
