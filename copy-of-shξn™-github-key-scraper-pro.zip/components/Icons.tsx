
import React from 'react';

export const StartIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <polygon points="5 3 19 12 5 21 5 3"></polygon>
    </svg>
);

export const ConfigIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <line x1="4" y1="21" x2="4" y2="14"></line>
        <line x1="4" y1="10" x2="4" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="12"></line>
        <line x1="12" y1="8" x2="12" y2="3"></line>
        <line x1="20" y1="21" x2="20" y2="16"></line>
        <line x1="20" y1="12" x2="20" y2="3"></line>
        <line x1="1" y1="14" x2="7" y2="14"></line>
        <line x1="9" y1="8" x2="15" y2="8"></line>
        <line x1="17" y1="16" x2="23" y2="16"></line>
    </svg>
);

export const DownloadIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
);

export const LoaderIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5 animate-spin">
        <line x1="12" y1="2" x2="12" y2="6"></line>
        <line x1="12" y1="18" x2="12" y2="22"></line>
        <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
        <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
        <line x1="2" y1="12" x2="6" y2="12"></line>
        <line x1="18" y1="12" x2="22" y2="12"></line>
        <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
        <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
    </svg>
);

export const CopyIcon: React.FC = () => (
     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect>
        <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>
    </svg>
);

export const CheckIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
);

export const ToolIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
    </svg>
);

export const SearchIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
);

export const GitHubIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.015-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.387-1.333-1.756-1.333-1.756-1.08-.745.084-.73.084-.73 1.19.084 1.81 1.226 1.81 1.226 1.06 1.809 2.78 1.287 3.44.98.107-.76.417-1.286.76-1.577-2.645-.295-5.429-1.32-5.429-5.92 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.11-3.18 0 0 1.005-.322 3.3 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.29-1.552 3.297-1.23 3.297-1.23.65 1.657.23 2.877.12 3.18.77.84 1.235 1.91 1.235 3.22 0 4.61-2.795 5.62-5.44 5.917.42.358.81 1.07.81 2.164 0 1.573-.015 2.843-.015 3.223 0 .309.21.69.825.575C19.565 22.092 23 17.592 23 12.297c0-6.627-5.373-12-12-12Z"/>
    </svg>
);

export const OpenAIIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M22.253 10.316a1.002 1.002 0 0 0-.806-.806c-3.14-.784-6.071-.784-9.211 0a1.002 1.002 0 0 0-.806.806c-.784 3.14-.784 6.071 0 9.211a1.002 1.002 0 0 0 .806.806c3.14.784 6.071.784 9.211 0a1.002 1.002 0 0 0 .806-.806c.784-3.14.784-6.071 0-9.211zM6.57 6.57a1.002 1.002 0 0 0-.806-.806c-.784-.784-1.569-1.569-2.353-2.353-.02-.02-.041-.041-.061-.061a.99.99 0 0 0-1.393-.01c-.398.398-.795.795-1.193 1.193a.99.99 0 0 0-.01 1.393c.02.02.041.041.061.061 2.353 2.353 4.706 4.706 7.059 7.059a1.002 1.002 0 0 0 .806.806c.784.784 1.569 1.569 2.353 2.353.02.02.041.041.061.061a.99.99 0 0 0 1.393.01c.398-.398.795-.795 1.193-1.193a.99.99 0 0 0 .01-1.393c-.02-.02-.041-.041-.061-.061-2.353-2.353-4.706-4.706-7.059-7.059zM17.43 6.57a1.002 1.002 0 0 0-.806-.806c-.784-.784-1.569-1.569-2.353-2.353-.02-.02-.041-.041-.061-.061a.99.99 0 0 0-1.393-.01c-.398.398-.795.795-1.193 1.193a.99.99 0 0 0-.01 1.393c.02.02.041.041.061.061 2.353 2.353 4.706 4.706 7.059 7.059a1.002 1.002 0 0 0 .806.806c.784.784 1.569 1.569 2.353 2.353.02.02.041.041.061.061a.99.99 0 0 0 1.393.01c.398-.398.795-.795 1.193-1.193a.99.99 0 0 0 .01-1.393c-.02-.02-.041-.041-.061-.061-2.353-2.353-4.706-4.706-7.059-7.059z"/>
    </svg>
);

export const GeminiIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" className="w-5 h-5">
        <path d="M12 11.2V12.8H18.9167C18.6667 13.9167 18.0417 15.3333 16.9167 16.1458C15.8333 16.9583 14.5417 17.4375 12 17.4375C9.04167 17.4375 6.5625 15.25 6.5625 12.2917C6.5625 9.33333 9.04167 7.14583 12 7.14583C13.5417 7.14583 14.875 7.77083 15.9167 8.70833L17.5833 7.14583C16.0208 5.70833 14.1667 5 12 5C7.29167 5 3.5 8.79167 3.5 13.5C3.5 18.2083 7.29167 22 12 22C16.7083 22 20.5 18.2083 20.5 13.5C20.5 12.875 20.4375 12.2917 20.3333 11.7083H12V11.2Z" fill="#EA4335"/>
        <path d="M12 5V7.14583H12.0625L12 5Z" fill="#4285F4"/>
        <path d="M3.5 13.5C3.5 13.5 7.29167 13.5 12 13.5C12 13.5 12 11.2 12 11.2H3.5C3.5 11.2 3.5 13.5 3.5 13.5Z" fill="#FBBC04"/>
        <path d="M12 17.4375C14.5417 17.4375 17.5 16.5208 17.5 13.5H12C12 13.5 12 17.4375 12 17.4375Z" fill="#34A853"/>
    </svg>
);

export const ExternalLinkIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4">
        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
        <polyline points="15 3 21 3 21 9"></polyline>
        <line x1="10" y1="14" x2="21" y2="3"></line>
    </svg>
);
