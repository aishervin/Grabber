import React, { useState, useCallback, useRef } from 'react';
import type { ScrapeStatus, ScrapeResults, LogEntry, ApiService, ConfigType } from './types';
import { ALL_SERVICES } from './types';
import { generateSearchQuery } from './services/geminiService';
import { validateAndExtractKeys } from './services/extractionService';
import { searchGitHub, checkGitHubToken, SERVICE_QUERIES } from './services/githubService';
import { LogDisplay } from './components/LogDisplay';
import { ProgressBar } from './components/ProgressBar';
import { Footer } from './components/Footer';
import { ResultsDisplay } from './components/ResultsDisplay';
import { StartIcon, ConfigIcon, ExternalLinkIcon } from './components/Icons';

// Hardcoded GitHub tokens as requested for personal use.
const GITHUB_TOKENS = [
    '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', // Priority Key
    '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',
    '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',
    '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',
    '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',
    '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', 
];

type QueryTask = { query: string; type: ApiService | 'Custom' | string };

const App: React.FC = () => {
    const [status, setStatus] = useState<ScrapeStatus>('idle');
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [progress, setProgress] = useState<number>(0);
    const [results, setResults] = useState<ScrapeResults>({});
    
    const [selectedServices, setSelectedServices] = useState<Set<ApiService>>(new Set());
    const [isCustomSelected, setIsCustomSelected] = useState<boolean>(false);
    const [customQuery, setCustomQuery] = useState<string>('');
    
    // New state for the dedicated config finder
    const [isConfigFinderVisible, setIsConfigFinderVisible] = useState<boolean>(false);
    const [configType, setConfigType] = useState<ConfigType>('V2Ray');
    const [configCountry, setConfigCountry] = useState<string>('');

    const abortControllerRef = useRef<AbortController | null>(null);

    const addLog = useCallback((message: string, type: 'info' | 'error' | 'success' = 'info') => {
        setLogs(prev => [...prev, { message, type, timestamp: new Date().toLocaleTimeString() }]);
    }, []);

    const handleServiceToggle = (service: ApiService) => {
        setSelectedServices(prev => {
            const newSet = new Set(prev);
            if (newSet.has(service)) newSet.delete(service);
            else newSet.add(service);
            return newSet;
        });
    };
    
    const handleStop = useCallback(() => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            addLog('⛔ Stopping process requested by user...', 'error');
        }
    }, [addLog]);

    const handleStart = useCallback(async () => {
        if (status === 'processing') return;

        // Reset state
        setStatus('processing');
        setLogs([]);
        setResults({});
        setProgress(0);
        abortControllerRef.current = new AbortController();
        const { signal } = abortControllerRef.current;
        
        const tasks: QueryTask[] = [];
        
        // 1. Collect API service tasks
        selectedServices.forEach(service => {
            SERVICE_QUERIES[service].forEach(q => tasks.push({ query: q, type: service }));
        });

        // 2. Collect Config Finder task
        if (isConfigFinderVisible) {
            if (!configType || !configCountry.trim()) {
                addLog('❌ For Config Finder, please select a type and enter a country.', 'error');
                setStatus('error');
                return;
            }
            const typeKeywords: Record<ConfigType, string> = {
                V2Ray: '("v2ray" OR "vmess" OR "vless")',
                Shadowsocks: '("shadowsocks" OR "ss")',
                Trojan: '("trojan" OR "trojan-go")',
            };
            const countryTerm = `("${configCountry.trim().replace(/ /g, '" OR "')}")`;
            const fileExtensions = 'extension:txt extension:json extension:yaml';
            const configQuery = `${typeKeywords[configType]} ${countryTerm} ${fileExtensions} sort:updated-desc`;
            
            tasks.push({ query: configQuery, type: `${configType} Configs` });
            addLog(`🔎 Prepared specialized query for ${configType} configs in ${configCountry}`);
        }
        
        // 3. Collect Custom Search task (after AI processing)
        if (isCustomSelected) {
            if (!customQuery.trim()) {
                addLog('❌ Please describe your custom search or deselect "Custom".', 'error');
                setStatus('error');
                return;
            }
            addLog(`🤖 Converting natural language to GitHub query: "${customQuery}"`);
            try {
                const generatedQuery = await generateSearchQuery(customQuery, signal);
                addLog(`✅ AI generated query: "${generatedQuery}"`, 'success');
                tasks.push({ query: generatedQuery, type: 'Custom' });
            } catch (error) {
                 if (signal.aborted || (error instanceof Error && error.name === 'AbortError')) {
                    addLog('🛑 Process stopped by user during query generation.', 'error');
                    setStatus('idle');
                    setProgress(100);
                    return;
                }
                addLog(`❌ Failed to generate GitHub query.`, 'error');
                setStatus('error');
                return;
            }
        }
        
        if (tasks.length === 0) {
            addLog('❌ Please select at least one service or configure a search to start.', 'error');
            setStatus('idle');
            return;
        }

        addLog(`🚀 Automation started for ${tasks.length} total search queries.`);
        
        try {
            const healthyTokens = await performHealthCheck(signal);
            if (healthyTokens.length === 0) {
                addLog('❌ Critical Error: No valid GitHub tokens available.', 'error');
                setStatus('error');
                setProgress(100);
                return;
            }
            
            addLog(`⚡️ Using ${healthyTokens.length} healthy tokens for parallel search.`);

            await searchGitHub(
                healthyTokens, 
                tasks, 
                (searchProgress, message) => {
                    if (signal.aborted) return;
                    setProgress(p => Math.max(p, 10 + Math.floor(searchProgress * 0.9))); 
                    addLog(message);
                },
                processSnippetsFound,
                signal
            );

            if (!signal.aborted) {
                setProgress(100);
                setStatus('success');
                addLog('🎉 All processes completed successfully!', 'success');
            }
        } catch (error) {
            if (error instanceof Error && (error.message.includes('stopped by user') || error.name === 'AbortError')) {
                addLog('🛑 Process stopped by user.', 'error');
                setStatus('idle');
            } else {
                const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
                addLog(`❌ A critical error halted the process: ${errorMessage}`, 'error');
                setStatus('error');
            }
            setProgress(100);
        } finally {
            abortControllerRef.current = null;
        }
    }, [status, addLog, selectedServices, isCustomSelected, customQuery, isConfigFinderVisible, configType, configCountry]);

    const performHealthCheck = async (signal: AbortSignal) => {
        addLog(`🩺 Performing health check on ${GITHUB_TOKENS.length} GitHub tokens...`);
        const healthyTokens: string[] = [];
        for (const token of GITHUB_TOKENS) {
            if (signal.aborted) throw new Error('Process stopped by user');
            const result = await checkGitHubToken(token);
            if (result.valid) {
                healthyTokens.push(token);
                addLog(`✅ Token ****${token.slice(-4)} is healthy.`);
            } else {
                addLog(`❌ Token ****${token.slice(-4)} failed health check: ${result.reason}`, 'error');
            }
        }
        return healthyTokens;
    };
    
    const processSnippetsFound = useCallback(async (snippets: string[], type: string) => {
        const { signal } = abortControllerRef.current ?? {};
        if (signal?.aborted) return;

        const isApiService = ALL_SERVICES.includes(type as ApiService);

        if (isApiService) {
            addLog(`⚙️ Processing ${snippets.length} snippets for ${type} keys...`);
            const newKeys = validateAndExtractKeys(snippets, [type]);
            const newKeyCount = Object.values(newKeys).reduce((sum, keys) => sum + (keys?.length ?? 0), 0);
            
            if (newKeyCount > 0) {
                addLog(`✅ Extracted ${newKeyCount} potential keys for ${type}.`, 'success');
                setResults(prev => {
                    const updated = { ...prev };
                    Object.keys(newKeys).forEach(service => {
                        updated[service] = [...new Set([...(updated[service] || []), ...(newKeys[service] || [])])];
                    });
                    return updated;
                });
            }
        } else { // Handle 'Custom' or 'V2Ray Configs', etc.
            addLog(`Found ${snippets.length} raw snippets for "${type}".`, 'success');
            setResults(prev => ({
                ...prev,
                [type]: [...new Set([...(prev[type] || []), ...snippets])],
            }));
        }
    }, [addLog]);

    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden">
            {/* Background Decoration - Galaxy */}
            <div className="galaxy-container">
                <div className="stars"></div>
            </div>

            <main className="w-full max-w-4xl mx-auto bg-[#050505] border border-[#1a1a1a] rounded-3xl shadow-[0_0_80px_rgba(0,0,0,1)] p-8 space-y-8 relative z-10">
                <header className="text-center space-y-1">
                    <h1 className="text-5xl font-bold shen-gradient-text tracking-tighter uppercase drop-shadow-2xl">
                       SHΞN™ KEY SCRAPER
                    </h1>
                    <p className="text-gray-600 text-xs tracking-[0.5em] uppercase font-mono">Quantum Level Extraction Unit</p>
                </header>

                {/* Buttons Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {ALL_SERVICES.map(service => (
                        <button 
                            key={service} 
                            onClick={() => handleServiceToggle(service)} 
                            className={`
                                relative px-4 py-4 text-xs font-bold rounded-lg transition-all duration-200 uppercase tracking-wider
                                btn-cyber group
                                ${selectedServices.has(service) 
                                    ? 'btn-cyber-active' 
                                    : 'text-gray-500 hover:text-gray-300 hover:border-white/20'}
                            `}
                        >
                            <span className="relative z-10">{service}</span>
                        </button>
                    ))}
                    
                    {/* Config Button */}
                    <button 
                        onClick={() => setIsConfigFinderVisible(p => !p)} 
                        className={`
                            relative px-4 py-4 text-xs font-bold rounded-lg transition-all duration-200 flex items-center justify-center gap-2 uppercase tracking-wider
                            btn-cyber group
                            ${isConfigFinderVisible 
                                ? 'btn-cyber-active' 
                                : 'text-gray-500 hover:text-gray-300 hover:border-white/20'}
                        `}
                    >
                        <ConfigIcon /> 
                        <span>Configs</span>
                    </button>

                    {/* Custom Button (Double Width) */}
                    <button 
                        onClick={() => setIsCustomSelected(p => !p)} 
                        className={`
                            col-span-2 relative px-4 py-4 text-xs font-bold rounded-lg transition-all duration-200 uppercase tracking-wider
                            btn-cyber group
                            ${isCustomSelected 
                                ? 'btn-cyber-active' 
                                : 'text-gray-500 hover:text-gray-300 hover:border-white/20'}
                        `}
                    >
                         Custom Target
                    </button>
                </div>

                {/* Config Finder Section */}
                {isConfigFinderVisible && (
                    <div className="animate-fade-in p-6 bg-black/80 border border-white/5 rounded-2xl space-y-4 shadow-inner">
                        <h3 className="font-bold text-orange-500 text-sm uppercase tracking-widest flex items-center gap-2">
                            <ConfigIcon /> Protocol Configuration
                        </h3>
                        <div className="grid md:grid-cols-2 gap-5">
                            <div>
                                <label htmlFor="config-type" className="block text-[10px] font-bold text-gray-600 mb-2 uppercase tracking-wider">Protocol</label>
                                <div className="relative">
                                    <select id="config-type" value={configType} onChange={e => setConfigType(e.target.value as ConfigType)} className="w-full px-4 py-3 bg-[#0f0f0f] border border-gray-800 rounded-lg text-gray-300 focus:ring-1 focus:ring-orange-500/50 focus:border-orange-500 outline-none appearance-none transition-all cursor-pointer hover:bg-[#141414] text-sm">
                                        <option value="V2Ray">V2Ray (VMess/VLess)</option>
                                        <option value="Shadowsocks">Shadowsocks</option>
                                        <option value="Trojan">Trojan</option>
                                    </select>
                                    <div className="absolute inset-y-0 right-0 flex items-center px-4 pointer-events-none text-gray-500">
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label htmlFor="config-country" className="block text-[10px] font-bold text-gray-600 mb-2 uppercase tracking-wider">Target Region</label>
                                <input type="text" id="config-country" value={configCountry} onChange={e => setConfigCountry(e.target.value)} placeholder="e.g., Germany, IN, USA" className="w-full px-4 py-3 bg-[#0f0f0f] border border-gray-800 rounded-lg text-gray-300 focus:ring-1 focus:ring-orange-500/50 focus:border-orange-500 outline-none placeholder-gray-700 transition-all hover:bg-[#141414] text-sm" />
                            </div>
                        </div>
                    </div>
                )}
                
                {/* Custom Query Input */}
                 {isCustomSelected && (
                    <div className="relative animate-fade-in">
                        <input type="text" value={customQuery} onChange={(e) => setCustomQuery(e.target.value)} placeholder="COMMAND LINE INPUT: Describe target parameters..." className="w-full px-5 py-4 bg-black/60 border border-white/10 rounded-lg text-gray-200 focus:ring-1 focus:ring-orange-500/50 focus:border-orange-500 outline-none transition-all placeholder-gray-700 font-mono text-sm" />
                    </div>
                )}

                {/* Action Buttons */}
                <div className="pt-4">
                    {status === 'processing' ? (
                        <button onClick={handleStop} className="w-full flex items-center justify-center gap-3 px-6 py-6 bg-black text-orange-500 font-black text-xl rounded-xl border-2 border-orange-500 shadow-[0_0_30px_rgba(255,85,0,0.4)] transition-all duration-100 uppercase tracking-[0.2em] group">
                             <span className="text-flicker">ATTACK</span>
                        </button>
                    ) : (
                        <button onClick={handleStart} className="w-full flex items-center justify-center gap-3 px-6 py-6 bg-orange-500/60 hover:bg-orange-500/80 text-black font-black text-xl rounded-xl border border-orange-500 shadow-[0_0_20px_rgba(255,85,0,0.2)] hover:shadow-[0_0_40px_rgba(255,85,0,0.4)] transition-all duration-300 uppercase tracking-[0.2em] group backdrop-blur-sm">
                            <span>ATTACK</span>
                        </button>
                    )}
                </div>
                
                <div className="px-1 pt-2">
                   <ProgressBar progress={progress} status={status} />
                </div>

                <LogDisplay logs={logs} />
                
                {(status !== 'idle' && Object.keys(results).length > 0) && (
                    <ResultsDisplay results={results} addLog={addLog} />
                )}

                {/* External Tools */}
                <div className="pt-8 mt-4 border-t border-white/5">
                     <h3 className="text-[10px] font-bold text-gray-700 uppercase tracking-[0.3em] text-center mb-6">Secure Channels</h3>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <a 
                            href="https://shervinuri.github.io/Openaikeyverify" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="btn-cyber px-4 py-4 rounded-lg flex items-center justify-center gap-3 text-gray-500 hover:text-orange-400 hover:border-orange-500/30 transition-all duration-300 group"
                        >
                            <span className="text-[10px] font-bold uppercase tracking-widest">GPT Verify</span>
                            <ExternalLinkIcon />
                        </a>
                        <a 
                            href="https://shervinuri.github.io/Gemkeyverify" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="btn-cyber px-4 py-4 rounded-lg flex items-center justify-center gap-3 text-gray-500 hover:text-orange-400 hover:border-orange-500/30 transition-all duration-300 group"
                        >
                            <span className="text-[10px] font-bold uppercase tracking-widest">Gemini Verify</span>
                            <ExternalLinkIcon />
                        </a>
                        <a 
                            href="https://shervinuri.github.io/Githubtokenverify-/" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="btn-cyber px-4 py-4 rounded-lg flex items-center justify-center gap-3 text-gray-500 hover:text-orange-400 hover:border-orange-500/30 transition-all duration-300 group"
                        >
                            <span className="text-[10px] font-bold uppercase tracking-widest">GitHub Verify</span>
                            <ExternalLinkIcon />
                        </a>
                     </div>
                </div>

            </main>
            <Footer />
        </div>
    );
};

export default App;