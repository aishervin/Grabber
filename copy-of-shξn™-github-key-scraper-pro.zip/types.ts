export type ScrapeStatus = 'idle' | 'processing' | 'success' | 'error';

export const ALL_SERVICES = [
    'OpenAI',
    'Google',
    'GitHub',
    'Hugging Face',
    'OpenRouter',
    'Groq',
    'DeepSeek',
] as const;

export type ApiService = typeof ALL_SERVICES[number];

export type ConfigType = 'V2Ray' | 'Shadowsocks' | 'Trojan';

// Using a string index signature to allow for dynamic keys, including 'Custom' and generated types like "V2Ray Configs".
export type ScrapeResults = {
    [key: string]: string[] | undefined;
};

export interface ValidatedKeyResult {
    key: string;
    response: string;
}

export type ValidatedKeys = {
    [key: string]: ValidatedKeyResult[] | undefined;
};

export interface LogEntry {
    message: string;
    type: 'info' | 'error' | 'success';
    timestamp: string;
}
