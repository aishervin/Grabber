import type { ScrapeResults, ApiService } from '../types';

const SERVICE_PATTERNS: Record<string, RegExp> = {
    OpenAI: /sk-(proj-)?[a-zA-Z0-9]{20,}T3BlbkFJ[a-zA-Z0-9]{20,}|sk-[a-zA-Z0-9]{20,}/g,
    Google: /AIza[0-9A-Za-z-_]{35}/g,
    GitHub: /(ghp|gho|ghu|ghs|ghr)_[a-zA-Z0-9]{36}/g,
    'Hugging Face': /hf_[a-zA-Z0-9]{34}/g,
    OpenRouter: /sk-or-rut-[a-z0-9]{64}/g,
    Groq: /gsk_[a-zA-Z0-9]{52}/g,
    DeepSeek: /sk-[a-zA-Z0-9]{32,}/g // Generic sk- pattern often used
};

/**
 * Pure JavaScript extraction of potential keys.
 */
const extractCandidatesWithRegex = (text: string, selectedServices: string[]): ScrapeResults => {
    const results: ScrapeResults = {};

    selectedServices.forEach(service => {
        // We might get "V2Ray Configs", etc. which don't have patterns.
        // The check below handles this gracefully.
        const regex = SERVICE_PATTERNS[service];
        if (regex) {
            const matches = text.match(regex);
            if (matches) {
                // Filter duplicates
                results[service] = [...new Set(matches)];
            }
        }
    });

    return results;
};


/**
 * Processes code snippets to extract potential API keys based on regex patterns.
 * This is a synchronous function for performance.
 */
export const validateAndExtractKeys = (
    snippets: string[],
    selectedServices: string[]
): ScrapeResults => {
    // Combine snippets into a single string for efficient regex matching.
    const combinedText = snippets.join('\n\n');
    
    // Directly use the pure JavaScript Regex extraction.
    return extractCandidatesWithRegex(combinedText, selectedServices);
};
