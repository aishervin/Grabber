import type { ScrapeResults, ValidatedKeys, ValidatedKeyResult, ApiService } from '../types';

const TEST_PROMPT = "ساعت دقیق به وقت تهران رو تا صدم ثانیه  در همین لحظه برای من  با این فرمت 00:00:00:00 بنویس";

// Helper for OpenAI-compatible APIs
const testOpenAICompatibleKey = async (
    key: string,
    url: string,
    model: string
): Promise<string | null> => {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${key}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model,
                messages: [{ role: 'user', content: TEST_PROMPT }],
                max_tokens: 50,
                temperature: 0,
            }),
        });

        if (!response.ok) {
            return null; // Invalid key or other error
        }

        const data = await response.json();
        return data.choices?.[0]?.message?.content?.trim() || "✅ Received a valid response, but content was empty.";
    } catch (error) {
        console.error(`Network error during key test for model ${model}`, error);
        return null;
    }
};

const testGoogleKey = async (key: string): Promise<string | null> => {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${key}`;
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: TEST_PROMPT }] }],
            }),
        });

        if (!response.ok) {
            return null;
        }

        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "✅ Received a valid response, but content was empty.";
    } catch (error) {
        console.error('Network error during Google key test', error);
        return null;
    }
};

// For services that don't have a generative AI endpoint, we just validate authentication.
const testAuthOnlyKey = async (key: string, url: string): Promise<string | null> => {
    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${key}` },
        });

        return response.ok ? "✅ Authentication successful (key is valid)." : null;
    } catch (error) {
        console.error(`Network error during auth-only test for url ${url}`, error);
        return null;
    }
};

// Map services to their test functions
const SERVICE_TESTERS: Record<ApiService, (key: string) => Promise<string | null>> = {
    OpenAI: (key) => testOpenAICompatibleKey(key, 'https://api.openai.com/v1/chat/completions', 'gpt-3.5-turbo'),
    Google: testGoogleKey,
    GitHub: (key) => testAuthOnlyKey(key, 'https://api.github.com/user'),
    'Hugging Face': (key) => testAuthOnlyKey(key, 'https://huggingface.co/api/whoami-v2'),
    OpenRouter: (key) => testOpenAICompatibleKey(key, 'https://openrouter.ai/api/v1/chat/completions', 'google/gemini-flash-1.5'),
    Groq: (key) => testOpenAICompatibleKey(key, 'https://api.groq.com/openai/v1/chat/completions', 'llama3-8b-8192'),
    DeepSeek: (key) => testOpenAICompatibleKey(key, 'https://api.deepseek.com/v1/chat/completions', 'deepseek-chat'),
};


export const validateKeys = async (
    potentialKeys: ScrapeResults,
    onProgress: (progress: number, message: string) => void
): Promise<ValidatedKeys> => {
    const validatedResults: ValidatedKeys = {};
    const allKeys: { key: string; type: keyof ScrapeResults }[] = [];
    
    (Object.keys(potentialKeys) as Array<keyof ScrapeResults>).forEach(service => {
        const keys = potentialKeys[service];
        if (keys) {
            validatedResults[service] = []; // Initialize array
            keys.forEach(key => allKeys.push({ key, type: service }));
        }
    });

    if (allKeys.length === 0) {
        onProgress(100, "No potential keys to test.");
        return validatedResults;
    }
    
    let processedCount = 0;
    
    const validationPromises = allKeys.map(async ({ key, type }) => {
        let responseText: string | null = null;
        
        if (type === 'Custom') {
            responseText = "Not tested - custom query result.";
        } else {
            const tester = SERVICE_TESTERS[type as ApiService];
            if (tester) {
                responseText = await tester(key);
            }
        }
        
        processedCount++;
        const progress = (processedCount / allKeys.length) * 100;
        onProgress(progress, `Testing key ${processedCount}/${allKeys.length}... (${type})`);

        if (responseText) {
            return { key, type, response: responseText };
        }
        return null;
    });

    const settledResults = await Promise.all(validationPromises);

    settledResults.forEach(result => {
        if (result) {
            if (!validatedResults[result.type]) {
                validatedResults[result.type] = [];
            }
            validatedResults[result.type]!.push({ key: result.key, response: result.response });
        }
    });

    return validatedResults;
};