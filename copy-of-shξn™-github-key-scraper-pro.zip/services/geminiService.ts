
const API_URL = 'https://text.pollinations.ai/openai';
const MAX_RETRIES = 3;

export const generateSearchQuery = async (userPrompt: string, signal?: AbortSignal): Promise<string> => {
    const systemPrompt = `You are a world-class GitHub Dorking expert. Your sole purpose is to convert natural language requests into a single, highly effective, and precise GitHub search query.

**CRITICAL RULES:**
- Your output MUST be the raw query string and nothing else. No explanations, no markdown.
- When searching for multiple file types, you MUST list them with spaces (e.g., \`extension:json extension:yaml\`). You MUST NOT use 'OR' between extensions.
- You MUST NOT use the \`AND\` keyword. Spaces are the implicit \`AND\`.
- You MUST NOT include emojis (e.g., 🇮🇳) in the query as they are unreliable in code search.

**PROCESS:**
1.  **Analyze:** Identify the core subject (e.g., 'v2ray config'), keywords, and qualifiers (e.g., country 'India').
2.  **Expand:** Create OR groups for keywords and qualifiers. For countries, use the English name, ISO code, and common server identifiers. Example: \`("India" OR "IN" OR "loc-in")\`.
3.  **Target Files:** If file types are mentioned, use them. If not specified, default to common config/text formats like \`extension:json extension:yaml extension:ini extension:txt\`.
4.  **Assemble:** Combine keyword/qualifier groups with spaces. Append file extensions. Append \`sort:updated-desc\` at the end.

**GOOD EXAMPLE:**
User Request: "Find active v2ray subscription links for India, preferably as json, yaml, or text files."
Correct Output: ("v2ray" OR "shadowsocks" OR "config") ("India" OR "IN" OR "loc-in") extension:json extension:yaml extension:txt sort:updated-desc

**BAD EXAMPLE (WHAT TO AVOID):**
Incorrect Output: \`("v2ray" OR "config") AND ("India") extension:json OR extension:txt\`
(This is wrong because it uses the 'AND' keyword and uses 'OR' for extensions.)

Now, process the following user request, adhering strictly to all rules.
User Request: "${userPrompt}"`;

    const messages = [
        { role: 'system', content: systemPrompt.trim() },
        { role: 'user', content: userPrompt }
    ];

    let attempts = 0;
    while (attempts < MAX_RETRIES) {
        attempts++;
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ messages }),
                signal
            });

            if (!response.ok) {
                throw new Error(`AI API request failed with status ${response.status}`);
            }

            const data = await response.json();
            const query = data.choices?.[0]?.message?.content;

            if (!query) {
                throw new Error("Received an empty or invalid response from the AI.");
            }

            return query.trim().replace(/`/g, ''); // Clean up potential markdown artifacts
        } catch (error) {
            if (signal?.aborted || (error instanceof Error && error.name === 'AbortError')) {
                throw new Error('AbortError');
            }
            console.error(`Attempt ${attempts} to generate query failed:`, error);
            if (attempts >= MAX_RETRIES) {
                throw new Error("Failed to generate query after multiple attempts. The AI service may be temporarily unavailable.");
            }
            // Exponential backoff
            await new Promise(resolve => setTimeout(resolve, 1000 * attempts));
        }
    }
    // This part should be unreachable if the loop logic is correct
    throw new Error("An unexpected error occurred in generateSearchQuery.");
};
