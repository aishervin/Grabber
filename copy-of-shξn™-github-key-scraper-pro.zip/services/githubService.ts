import type { ApiService } from '../types';

const GITHUB_API_URL = 'https://api.github.com/search/code';
const GITHUB_RATE_LIMIT_URL = 'https://api.github.com/rate_limit';

export const SERVICE_QUERIES: Record<ApiService, string[]> = {
    OpenAI: [
        'OPENAI_API_KEY "sk-proj-"',
        'OPENAI_API_KEY "sk-"',
        '"Authorization: Bearer sk-proj-"',
        'filename:.env OPENAI_API_KEY',
    ],
    Google: [
        'GOOGLE_API_KEY "AIzaSy"',
        'gcloud auth "AIzaSy"',
        'filename:.env GOOGLE_API_KEY',
        'language:java "AIzaSy"',
    ],
    GitHub: [
        'GITHUB_TOKEN "ghp_"',
        'GITHUB_TOKEN "gho_"',
        'filename:.env GITHUB_TOKEN',
        '"Authorization: token ghp_"',
    ],
    'Hugging Face': [
        'HF_TOKEN "hf_"',
        'HUGGING_FACE_HUB_TOKEN "hf_"',
        'filename:.env HF_TOKEN',
    ],
    OpenRouter: [
        'OPENROUTER_API_KEY "sk-or-rut-"',
        '"Authorization: Bearer sk-or-rut-"',
    ],
    Groq: [
        'GROQ_API_KEY "gsk_"',
        '"Authorization: Bearer gsk_"',
    ],
    DeepSeek: [
        'DEEPSEEK_API_KEY "sk-"',
        'deepseek "sk-"', // Contextual search
    ],
};

interface TextMatch {
    fragment: string;
}

interface SearchResultItem {
    text_matches: TextMatch[];
}

interface GitHubSearchResponse {
    items: SearchResultItem[];
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const parseLinkHeader = (header: string | null): { [key: string]: string } => {
    if (!header) return {};
    const links: { [key: string]: string } = {};
    header.split(',').forEach(part => {
        const section = part.split(';');
        if (section.length < 2) return;
        const url = section[0].replace(/<(.*)>/, '$1').trim();
        const name = section[1].replace(/rel="(.*)"/, '$1').trim();
        links[name] = url;
    });
    return links;
};

export const checkGitHubToken = async (token: string): Promise<{ valid: boolean; reason?: string }> => {
    try {
        const response = await fetch(GITHUB_RATE_LIMIT_URL, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'X-GitHub-Api-Version': '2022-11-28'
            }
        });
        if (!response.ok) {
            return { valid: false, reason: `Status ${response.status} - Invalid or expired` };
        }
        return { valid: true };
    } catch (error) {
        // GitHub API drops CORS headers on 401 responses, which results in a "Failed to fetch" TypeError in browsers.
        const msg = error instanceof Error ? error.message : String(error);
        console.error(`Error checking token ****${token.slice(-4)}:`, msg);
        if (msg.includes('Failed to fetch')) {
             return { valid: false, reason: 'Failed to fetch (Likely revoked/CORS blocked)' };
        }
        return { valid: false, reason: msg };
    }
};

type QueryTask = { query: string; type: string };

export const searchGitHub = async (
    tokens: string[],
    tasks: QueryTask[],
    onProgress: (progress: number, message: string) => void,
    onSnippetsFound: (snippets: string[], type: string) => Promise<void>,
    signal?: AbortSignal
): Promise<void> => {
    if (tasks.length === 0) {
        onProgress(100, "No search queries to execute.");
        return;
    }
    
    const totalQueries = tasks.length;

    const searchWorker = async (token: string, tasksForWorker: QueryTask[], workerStartIndex: number) => {
        const tokenIdentifier = `Token ****${token.slice(-4)}`;

        for (let i = 0; i < tasksForWorker.length; i++) {
            if (signal?.aborted) return; // Stop worker immediately

            const task = tasksForWorker[i];
            const query = task.query;
            const overallQueryIndex = workerStartIndex + i;
            const progress = (overallQueryIndex / totalQueries) * 100;
            
            let nextPageUrl: string | null = `${GITHUB_API_URL}?q=${encodeURIComponent(query)}&per_page=100`;
            let pageCount = 0;

            while (nextPageUrl) {
                if (signal?.aborted) return; // Stop pagination immediately

                pageCount++;
                onProgress(progress, `[${tokenIdentifier}] Query ${overallQueryIndex + 1}/${totalQueries}: "${query}" (Page ${pageCount})`);
                
                try {
                    const response = await fetch(nextPageUrl, {
                         headers: {
                            'Accept': 'application/vnd.github.v3.text-match+json',
                            'Authorization': `Bearer ${token}`,
                            'X-GitHub-Api-Version': '2022-11-28'
                        },
                        signal // Pass signal to fetch to cancel network request
                    });

                    if (response.ok) {
                        const data: GitHubSearchResponse = await response.json();
                        if (data.items) {
                            const pageSnippets = data.items.flatMap(item => 
                                item.text_matches?.map(match => match.fragment) ?? []
                            );
                            if (pageSnippets.length > 0) {
                                await onSnippetsFound(pageSnippets, task.type);
                            }
                        }
                        const links = parseLinkHeader(response.headers.get('Link'));
                        nextPageUrl = links.next || null;
                        
                        if (nextPageUrl) await sleep(2100);
                        
                    } else {
                        if (response.status === 403 || response.status === 429) {
                            const retryAfter = response.headers.get('retry-after');
                            const rateLimitReset = response.headers.get('x-ratelimit-reset');
                            
                            let waitTime = 60000;
                            if (retryAfter) {
                                waitTime = parseInt(retryAfter, 10) * 1000;
                            } else if (rateLimitReset) {
                                waitTime = Math.max((parseInt(rateLimitReset, 10) * 1000) - Date.now(), 60000); // at least 60s
                            }
                            const resetTime = new Date(Date.now() + waitTime).toLocaleTimeString();
                            
                            onProgress(progress, `⏳ [${tokenIdentifier}] GitHub rate limit hit (${response.status}). Pausing until ${resetTime}...`);
                            // We use a loop for sleep to check signal periodically
                            const sleepStart = Date.now();
                            while (Date.now() - sleepStart < waitTime + 1000) {
                                if (signal?.aborted) return;
                                await sleep(500);
                            }
                            
                            pageCount--;
                            continue;
                        }
                        
                        if (response.status === 401) {
                            throw new Error(`[${tokenIdentifier}] GitHub API request failed: Unauthorized. Please check your token.`);
                        }

                        if (response.status === 422) {
                            onProgress(progress, `⚠️ [${tokenIdentifier}] Malformed query "${query}". Skipping.`);
                            nextPageUrl = null;
                            continue;
                        } 
                        
                        throw new Error(`[${tokenIdentifier}] GitHub API request failed with status ${response.status}: ${response.statusText}`);
                    }
                } catch (error) {
                    if (signal?.aborted || (error instanceof Error && error.name === 'AbortError')) return;

                    onProgress(progress, `❌ [${tokenIdentifier}] Error during search for query "${query}". Skipping.`);
                    console.error(`Error processing query "${query}" with ${tokenIdentifier}:`, error);
                    nextPageUrl = null;
                    if (error instanceof Error && error.message.includes("Unauthorized")) {
                         throw error;
                    }
                }
            }
        }
    };

    const queriesPerToken = Math.ceil(totalQueries / tokens.length);
    const workerPromises = tokens.map((token, index) => {
        const startIndex = index * queriesPerToken;
        const endIndex = Math.min(startIndex + queriesPerToken, totalQueries);
        const tasksForThisWorker = tasks.slice(startIndex, endIndex);

        if (tasksForThisWorker.length > 0) {
            return searchWorker(token, tasksForThisWorker, startIndex);
        }
        return Promise.resolve();
    });

    await Promise.all(workerPromises);

    if (!signal?.aborted) {
        onProgress(100, `GitHub search stream complete.`);
    }
};